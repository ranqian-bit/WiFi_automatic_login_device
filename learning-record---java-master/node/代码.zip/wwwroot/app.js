// 初始化Matter.js
const { Engine, Render, World, Bodies, Body, Events } = Matter;

// 服务器API地址
const API_URL = '/api/group-data';

// 荧光边框样式数组
const glowStyles = [
    'group-glow-1', 'group-glow-2', 'group-glow-3', 'group-glow-4', 'group-glow-5',
    'group-glow-1', 'group-glow-2', 'group-glow-3', 'group-glow-4', 'group-glow-5',
    'group-glow-1', 'group-glow-2', 'group-glow-3', 'group-glow-4', 'group-glow-5',
    'group-glow-1', 'group-glow-2', 'group-glow-3', 'group-glow-4', 'group-glow-5'
];

// 应用状态
let appState = {
    ungrouped: [],
    groups: []
};

// 开门状态
let openGroups = new Set();

// 初始化应用
async function initApp() {
    // 从服务器加载数据
    await loadFromServer();
    
    // 渲染UI
    renderUI();
    
    // 初始化拖放功能
    initDragAndDrop();
    
    // 添加导出按钮
    addExportButton();
    
    // 初始化烟花效果
    initFireworks();
    
    // 屏蔽鼠标右键和文字选择
    disableContextMenuAndSelection();
    
    // 定期刷新数据（每5秒）
    setInterval(async () => {
        const currentHash = JSON.stringify(appState);
        await loadFromServer();
        const newHash = JSON.stringify(appState);
        
        // 如果数据发生变化，重新渲染UI
        if (currentHash !== newHash) {
            renderUI();
            initDragAndDrop();
        }
    }, 5000);
}

// 从服务器加载数据
async function loadFromServer() {
    try {
        const response = await fetch(API_URL);
        if (response.ok) {
            const data = await response.json();
            appState = data;
        } else {
            console.error('从服务器加载数据失败:', response.status);
        }
    } catch (error) {
        console.error('加载数据异常:', error);
    }
}

// 保存数据到服务器
async function saveToServer() {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(appState)
        });
        
        if (!response.ok) {
            console.error('保存数据到服务器失败:', response.status);
        }
    } catch (error) {
        console.error('保存数据异常:', error);
    }
}

// 渲染UI
function renderUI() {
    const ungroupedContainer = document.getElementById('ungrouped');
    const groupsGrid = document.querySelector('.groups-grid');
    
    // 清空容器
    ungroupedContainer.innerHTML = '';
    groupsGrid.innerHTML = '';
    
    // 渲染未分组的学生
    appState.ungrouped.forEach((student, index) => {
        const personElement = createPersonElement(student, index, 'ungrouped');
        ungroupedContainer.appendChild(personElement);
    });
    
    // 渲染小组
    appState.groups.forEach((group, groupIndex) => {
        const groupElement = document.createElement('div');
        groupElement.className = `group ${glowStyles[groupIndex]}`;
        groupElement.setAttribute('data-group-index', groupIndex);
        
        // 检查小组是否已满
        // 根据用户需求：所有满员小组都显示相同的红色"已满员"覆盖层样式
        if (group.length >= 8) {
            groupElement.classList.add('group-full');
            groupElement.classList.add('group-full-overlay');
        }
        
        const groupTitle = document.createElement('h3');
        // 根据用户需求：所有满员小组都显示相同的标题格式
        groupTitle.textContent = `小组 ${groupIndex + 1} (${group.length}/8)`;
        
        const groupMembers = document.createElement('div');
        groupMembers.className = 'group-members';
        
        // 渲染小组中的学生
        group.forEach((student, index) => {
            const personElement = createPersonElement(student, index, `group-${groupIndex}`);
            groupMembers.appendChild(personElement);
        });
        
        groupElement.appendChild(groupTitle);
        groupElement.appendChild(groupMembers);
        groupsGrid.appendChild(groupElement);
    });
    
    // 增强UI，添加开门功能等
    enhanceRenderUI();
}

// 创建学生元素
function createPersonElement(student, index, source) {
    const personElement = document.createElement('div');
    personElement.className = 'person';
    personElement.setAttribute('draggable', 'true');
    personElement.setAttribute('data-source', source);
    personElement.setAttribute('data-index', index);
    personElement.setAttribute('data-id', student.id);
    
    const nameElement = document.createElement('div');
    nameElement.className = 'person-name';
    nameElement.textContent = student.name;
    
    const idElement = document.createElement('div');
    idElement.className = 'person-id';
    idElement.textContent = student.id;
    
    personElement.appendChild(nameElement);
    personElement.appendChild(idElement);
    
    return personElement;
}

// 初始化拖放功能
function initDragAndDrop() {
    const persons = document.querySelectorAll('.person');
    const groups = document.querySelectorAll('.group');
    const ungroupedContainer = document.getElementById('ungrouped');
    
    let draggedPerson = null;
    let draggedData = null;
    let touchStartX = 0;
    let touchStartY = 0;
    let isDragging = false;
    let lastTouchX = 0;
    let lastTouchY = 0;
    
    // 创建一个拖动预览元素
    let dragPreview = null;
    
    // 为每个学生元素添加拖放事件
    persons.forEach(person => {
        // 鼠标拖放事件
        person.addEventListener('dragstart', (e) => {
            draggedPerson = person;
            draggedData = {
                source: person.getAttribute('data-source'),
                index: parseInt(person.getAttribute('data-index')),
                id: person.getAttribute('data-id')
            };
            
            // 设置拖放效果
            e.dataTransfer.effectAllowed = 'move';
            // 创建一个半透明的拖动图像
            setTimeout(() => {
                person.style.opacity = '0.4';
            }, 0);
        });
        
        person.addEventListener('dragend', () => {
            if (draggedPerson) {
                draggedPerson.style.opacity = '1';
            }
            draggedPerson = null;
            draggedData = null;
            removeDragPreview();
        });
        
        // 触摸事件 - 移动端支持
        person.addEventListener('touchstart', (e) => {
            // 只处理单点触摸
            if (e.touches.length !== 1) return;
            
            // 记录触摸起始位置
            const touch = e.touches[0];
            touchStartX = touch.clientX;
            touchStartY = touch.clientY;
            lastTouchX = touch.clientX;
            lastTouchY = touch.clientY;
            
            // 标记为准备拖动
            isDragging = false;
            
            // 记录被拖动的元素
            draggedPerson = person;
            draggedData = {
                source: person.getAttribute('data-source'),
                index: parseInt(person.getAttribute('data-index')),
                id: person.getAttribute('data-id')
            };
            
            // 防止默认行为（如滚动）
            e.preventDefault();
        });
        
        person.addEventListener('touchmove', (e) => {
            if (!draggedPerson) return;
            
            // 只处理单点触摸
            if (e.touches.length !== 1) return;
            
            const touch = e.touches[0];
            const currentX = touch.clientX;
            const currentY = touch.clientY;
            
            // 计算移动距离
            const dx = Math.abs(currentX - touchStartX);
            const dy = Math.abs(currentY - touchStartY);
            
            // 如果移动距离超过一定阈值，开始拖动
            if (dx > 10 || dy > 10) {
                if (!isDragging) {
                    isDragging = true;
                    draggedPerson.style.opacity = '0.4';
                    createDragPreview(currentX, currentY);
                }
                
                // 更新拖动预览的位置
                updateDragPreviewPosition(currentX, currentY);
                
                // 更新最后触摸位置
                lastTouchX = currentX;
                lastTouchY = currentY;
                
                // 防止默认行为
                e.preventDefault();
            }
        });
        
        person.addEventListener('touchend', (e) => {
            if (!draggedPerson || !isDragging) {
                draggedPerson = null;
                draggedData = null;
                return;
            }
            
            // 找到触摸结束位置下的元素
            const endTarget = document.elementFromPoint(lastTouchX, lastTouchY);
            
            // 检查是否落在小组上
            let targetGroup = null;
            if (endTarget && endTarget.closest('.group')) {
                targetGroup = endTarget.closest('.group');
            }
            
            // 检查是否落在未分组区域
            let isUngroupedArea = false;
            if (endTarget && endTarget.closest('#ungrouped')) {
                isUngroupedArea = true;
            }
            
            // 处理拖放逻辑
            if (targetGroup) {
                const groupIndex = parseInt(targetGroup.getAttribute('data-group-index'));
                const groupData = appState.groups[groupIndex];
                
                // 检查小组是否允许添加成员
                if ((!targetGroup.classList.contains('group-full') && 
                    !targetGroup.classList.contains('group-full-overlay') && 
                    groupData.length < 8) || 
                    (openGroups.has(groupIndex) && groupData.length < 12)) {
                    
                    // 移动学生到小组
                    moveStudentToGroup(draggedData, groupIndex).catch(err => console.error('移动学生失败:', err));
                }
            } else if (isUngroupedArea) {
                // 如果学生来自某个小组，将其移回未分组区域
                if (draggedData.source.startsWith('group-')) {
                    const groupIndex = parseInt(draggedData.source.split('-')[1]);
                    moveStudentToUngrouped(groupIndex, draggedData.index).catch(err => console.error('移动学生失败:', err));
                }
            }
            
            // 重置状态
            draggedPerson.style.opacity = '1';
            draggedPerson = null;
            draggedData = null;
            isDragging = false;
            removeDragPreview();
        });
    });
    
    // 为小组添加拖放事件
    groups.forEach(group => {
        group.addEventListener('dragover', (e) => {
            e.preventDefault();
            const groupIndex = parseInt(group.getAttribute('data-group-index'));
            const groupData = appState.groups[groupIndex];
            // 检查小组是否允许添加成员
            if ((!group.classList.contains('group-full') && 
                !group.classList.contains('group-full-overlay') && 
                groupData.length < 8) || 
                (openGroups.has(groupIndex) && groupData.length < 12)) {
                group.style.transform = 'scale(1.02)';
            }
        });
        
        group.addEventListener('dragleave', () => {
            group.style.transform = '';
        });
        
        group.addEventListener('drop', (e) => {
            e.preventDefault();
            group.style.transform = '';
            
            const groupIndex = parseInt(group.getAttribute('data-group-index'));
            const groupData = appState.groups[groupIndex];
            
            // 检查小组是否允许添加成员
            if ((group.classList.contains('group-full') || 
                group.classList.contains('group-full-overlay') || 
                groupData.length >= 8) && 
                (!openGroups.has(groupIndex) || groupData.length >= 12)) {
                return;
            }
            
            if (draggedData && draggedPerson) {
                moveStudentToGroup(draggedData, groupIndex).catch(err => console.error('移动学生失败:', err));
            }
        });
    });
    
    // 为未分组区域添加拖放事件
    ungroupedContainer.addEventListener('dragover', (e) => {
        e.preventDefault();
        ungroupedContainer.style.background = 'rgba(255, 255, 255, 0.1)';
    });
    
    ungroupedContainer.addEventListener('dragleave', () => {
        ungroupedContainer.style.background = '';
    });
    
    ungroupedContainer.addEventListener('drop', (e) => {
        e.preventDefault();
        ungroupedContainer.style.background = '';
        
        if (draggedData && draggedPerson) {
            if (draggedData.source.startsWith('group-')) {
                const groupIndex = parseInt(draggedData.source.split('-')[1]);
                moveStudentToUngrouped(groupIndex, draggedData.index).catch(err => console.error('移动学生失败:', err));
            }
        }
    });
    
    // 创建拖动预览元素
    function createDragPreview(x, y) {
        // 移除已有的预览元素
        removeDragPreview();
        
        // 创建新的预览元素
        dragPreview = document.createElement('div');
        dragPreview.className = 'drag-preview';
        dragPreview.style.position = 'fixed';
        dragPreview.style.zIndex = '1000';
        dragPreview.style.opacity = '0.8';
        dragPreview.style.pointerEvents = 'none';
        dragPreview.style.transform = 'translate(-50%, -50%)';
        
        // 复制被拖动元素的内容和样式
        if (draggedPerson) {
            const name = draggedPerson.querySelector('.person-name').textContent;
            const id = draggedPerson.querySelector('.person-id').textContent;
            
            dragPreview.innerHTML = `<div class="person-name">${name}</div><div class="person-id">${id}</div>`;
            
            // 应用样式
            dragPreview.style.minWidth = '80px';
            dragPreview.style.padding = '8px';
            dragPreview.style.borderRadius = '8px';
            dragPreview.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
            dragPreview.style.color = '#333';
            dragPreview.style.fontSize = '14px';
            dragPreview.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
            dragPreview.style.textAlign = 'center';
        }
        
        // 设置位置并添加到文档
        dragPreview.style.left = `${x}px`;
        dragPreview.style.top = `${y}px`;
        document.body.appendChild(dragPreview);
    }
    
    // 更新拖动预览位置
    function updateDragPreviewPosition(x, y) {
        if (dragPreview) {
            dragPreview.style.left = `${x}px`;
            dragPreview.style.top = `${y}px`;
        }
    }
    
    // 移除拖动预览元素
    function removeDragPreview() {
        if (dragPreview && dragPreview.parentNode) {
            dragPreview.parentNode.removeChild(dragPreview);
            dragPreview = null;
        }
    }
}

// 将学生从一个位置移动到小组
async function moveStudentToGroup(draggedData, groupIndex) {
    let studentToMove;
    
    // 从源位置获取学生
    if (draggedData.source === 'ungrouped') {
        studentToMove = appState.ungrouped.splice(draggedData.index, 1)[0];
    } else if (draggedData.source.startsWith('group-')) {
        const sourceGroupIndex = parseInt(draggedData.source.split('-')[1]);
        studentToMove = appState.groups[sourceGroupIndex].splice(draggedData.index, 1)[0];
    }
    
    // 添加到目标小组 - 严格按照用户需求：未满8人可以继续添加，满8人提示已满员
    // 即使开门，满8人后也不能再添加（严格按照用户要求）
    if (studentToMove && appState.groups[groupIndex].length < 8) {
        appState.groups[groupIndex].push(studentToMove);
        
        // 保存状态并重新渲染
        await saveToServer();
        renderUI();
        initDragAndDrop();
        
        // 添加动画效果
        addPhysicsEffect(studentToMove.id);
    } else {
        // 如果条件不满足，将学生放回原位置
        if (studentToMove) {
            if (draggedData.source === 'ungrouped') {
                appState.ungrouped.splice(draggedData.index, 0, studentToMove);
            } else if (draggedData.source.startsWith('group-')) {
                const sourceGroupIndex = parseInt(draggedData.source.split('-')[1]);
                appState.groups[sourceGroupIndex].splice(draggedData.index, 0, studentToMove);
            }
        }
    }
}

// 将学生从小组移回未分组区域
async function moveStudentToUngrouped(groupIndex, studentIndex) {
    if (appState.groups[groupIndex] && appState.groups[groupIndex][studentIndex]) {
        const studentToMove = appState.groups[groupIndex].splice(studentIndex, 1)[0];
        appState.ungrouped.push(studentToMove);
        
        // 保存状态并重新渲染
        await saveToServer();
        renderUI();
        initDragAndDrop();
    }
}

// 添加物理效果
function addPhysicsEffect(studentId) {
    const studentElement = document.querySelector(`.person[data-id="${studentId}"]`);
    if (studentElement) {
        // 添加一个简单的弹跳动画
        studentElement.style.transition = 'transform 0.5s ease';
        studentElement.style.transform = 'scale(1.2)';
        
        setTimeout(() => {
            studentElement.style.transform = 'scale(1)';
        }, 300);
    }
}

// 初始化Matter.js物理引擎
function initPhysics() {
    // 创建引擎
    const engine = Engine.create();
    engine.world.gravity.y = 0.2; // 设置重力
    
    // 监听窗口大小变化，重新渲染UI
    window.addEventListener('resize', () => {
        renderUI();
        initDragAndDrop();
    });
}

// 初始化烟花效果
function initFireworks() {
    // 创建烟花容器
    const fireworksContainer = document.createElement('div');
    fireworksContainer.className = 'fireworks-container';
    document.body.appendChild(fireworksContainer);
    
    // 定期触发烟花效果
    setInterval(() => {
        if (Math.random() > 0.7) {
            createFirework();
        }
    }, 2000);
    
    // 添加点击产生烟花效果
    document.addEventListener('click', (e) => {
        createFirework(e.clientX, e.clientY);
    });
}

// 创建烟花
function createFirework(x = null, y = null) {
    const fireworksContainer = document.querySelector('.fireworks-container');
    
    // 随机位置或指定位置
    const startX = x || Math.random() * window.innerWidth;
    const startY = window.innerHeight;
    const endX = x || Math.random() * window.innerWidth;
    const endY = y || Math.random() * window.innerHeight * 0.6;
    
    // 创建发射粒子
    const rocket = document.createElement('div');
    rocket.className = 'firework';
    rocket.style.left = `${startX}px`;
    rocket.style.top = `${startY}px`;
    rocket.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
    rocket.style.width = '2px';
    rocket.style.height = '2px';
    fireworksContainer.appendChild(rocket);
    
    // 发射动画
    let startTime = null;
    const duration = 1000;
    
    function animate(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = (timestamp - startTime) / duration;
        
        if (progress < 1) {
            const currentX = startX + (endX - startX) * progress;
            const currentY = startY + (endY - startY) * progress;
            rocket.style.left = `${currentX}px`;
            rocket.style.top = `${currentY}px`;
            requestAnimationFrame(animate);
        } else {
            // 爆炸效果
            explodeFirework(endX, endY);
            fireworksContainer.removeChild(rocket);
        }
    }
    
    requestAnimationFrame(animate);
}

// 烟花爆炸效果
function explodeFirework(x, y) {
    const fireworksContainer = document.querySelector('.fireworks-container');
    const particleCount = Math.floor(Math.random() * 30) + 30;
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
    const selectedColor = colors[Math.floor(Math.random() * colors.length)];
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'firework';
        particle.style.left = `${x}px`;
        particle.style.top = `${y}px`;
        particle.style.backgroundColor = selectedColor;
        particle.style.width = `${Math.random() * 3 + 1}px`;
        particle.style.height = `${Math.random() * 3 + 1}px`;
        
        // 随机速度和角度
        const angle = (i / particleCount) * Math.PI * 2;
        const speed = Math.random() * 4 + 2;
        const vx = Math.cos(angle) * speed;
        const vy = Math.sin(angle) * speed;
        
        fireworksContainer.appendChild(particle);
        
        // 粒子动画
        let startTime = null;
        const duration = Math.random() * 1000 + 1000;
        const gravity = 0.02;
        
        function animateParticle(timestamp) {
            if (!startTime) startTime = timestamp;
            const progress = (timestamp - startTime) / duration;
            
            if (progress < 1) {
                const currentX = x + vx * progress * 100;
                const currentY = y + vy * progress * 100 + 0.5 * gravity * (progress * 100) * (progress * 100);
                particle.style.left = `${currentX}px`;
                particle.style.top = `${currentY}px`;
                particle.style.opacity = 1 - progress;
                requestAnimationFrame(animateParticle);
            } else {
                if (fireworksContainer.contains(particle)) {
                    fireworksContainer.removeChild(particle);
                }
            }
        }
        
        requestAnimationFrame(animateParticle);
    }
}

// 添加导出按钮
function addExportButton() {
    // 检查是否已存在导出按钮
    if (document.querySelector('.export-btn')) {
        return;
    }
    
    const exportBtn = document.createElement('button');
    exportBtn.className = 'export-btn';
    exportBtn.textContent = '导出Excel';
    document.body.appendChild(exportBtn);
    
    exportBtn.addEventListener('click', () => {
        exportToExcel();
    });
}

// 导出Excel表格
function exportToExcel() {
    // 准备数据
    const data = [];
    
    // 添加表头
    data.push(['小组序列', '姓名', '学号']);
    
    // 添加小组数据
    appState.groups.forEach((group, groupIndex) => {
        group.forEach(student => {
            data.push([`小组${groupIndex + 1}`, student.name, student.id]);
        });
    });
    
    // 添加未分组数据
    appState.ungrouped.forEach(student => {
        data.push(['未分组', student.name, student.id]);
    });
    
    // 创建CSV内容
    let csvContent = data.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    
    // 创建Blob对象
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    
    // 创建下载链接
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', '学生分组数据.csv');
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// 修改渲染UI函数以支持开门功能
function enhanceRenderUI() {
    // 在渲染UI后添加开门事件监听
    const groups = document.querySelectorAll('.group');
    
    groups.forEach(group => {
        const groupIndex = parseInt(group.getAttribute('data-group-index'));
        
        // 检查小组是否已满
        const groupData = appState.groups[groupIndex];
        if (groupData.length >= 8) {
            // 添加鼠标悬停效果（仅对满员且未开门的小组）
            if (!openGroups.has(groupIndex)) {
                group.addEventListener('mouseenter', () => {
                    if (!openGroups.has(groupIndex)) {
                        group.classList.add('group-door-open');
                    }
                });
                
                group.addEventListener('mouseleave', () => {
                    if (!openGroups.has(groupIndex)) {
                        group.classList.remove('group-door-open');
                    }
                });
            }
            
            // 添加点击开门事件
            group.addEventListener('click', () => {
                // 对于满员小组，只有在显示开门按钮时才能点击
                if (group.classList.contains('group-door-open') || openGroups.has(groupIndex)) {
                    // 切换开门状态
                    if (openGroups.has(groupIndex)) {
                        openGroups.delete(groupIndex);
                        group.classList.remove('group-door-open');
                    } else {
                        openGroups.add(groupIndex);
                        group.classList.remove('group-door-open');
                        // 播放开门烟花效果
                        createFirework(group.getBoundingClientRect().left + group.offsetWidth / 2, group.getBoundingClientRect().top + group.offsetHeight / 2);
                    }
                    // 更新标题显示
                    const groupTitle = group.querySelector('h3');
                    if (groupTitle) {
                        // 根据用户需求：所有满员小组都显示相同的标题格式
                        groupTitle.textContent = `小组 ${groupIndex + 1} (${appState.groups[groupIndex].length}/8)`;
                    }
                }
            });
        }
    });
}

// 重写渲染UI函数，在原函数基础上增强
const originalRenderUI = renderUI;
renderUI = function() {
    originalRenderUI();
    enhanceRenderUI();
};

// 屏蔽鼠标右键和文字选择
function disableContextMenuAndSelection() {
    // 屏蔽鼠标右键菜单
    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
    });
    
    // 屏蔽文字选择
    document.addEventListener('selectstart', (e) => {
        e.preventDefault();
    });
    
    // 禁用鼠标拖拽选择
    document.addEventListener('mousedown', (e) => {
        // 只有当不是拖拽操作时才阻止
        if (!e.target.classList.contains('person') && !draggedPerson) {
            e.preventDefault();
        }
    });
}

// 修改烟花爆炸效果，使其更绚丽
function explodeFirework(x, y) {
    const fireworksContainer = document.querySelector('.fireworks-container');
    const particleCount = Math.floor(Math.random() * 40) + 60; // 增加粒子数量
    const colors = [
        '#ff0000', '#ff4000', '#ff8000', '#ffbf00', '#ffff00',
        '#bfff00', '#80ff00', '#40ff00', '#00ff00', '#00ff40',
        '#00ff80', '#00ffbf', '#00ffff', '#00bfff', '#0080ff',
        '#0040ff', '#0000ff', '#4000ff', '#8000ff', '#bf00ff',
        '#ff00ff', '#ff00bf', '#ff0080', '#ff0040'
    ];
    
    // 创建多个颜色的烟花爆炸
    const colorCount = Math.floor(Math.random() * 3) + 1; // 1-3种颜色
    const selectedColors = [];
    
    for (let c = 0; c < colorCount; c++) {
        const color = colors[Math.floor(Math.random() * colors.length)];
        if (!selectedColors.includes(color)) {
            selectedColors.push(color);
        }
    }
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'firework';
        particle.style.left = `${x}px`;
        particle.style.top = `${y}px`;
        
        // 为粒子选择一种颜色
        const color = selectedColors[Math.floor(Math.random() * selectedColors.length)];
        particle.style.backgroundColor = color;
        particle.style.width = `${Math.random() * 4 + 1}px`;
        particle.style.height = `${Math.random() * 4 + 1}px`;
        particle.style.borderRadius = '50%';
        
        // 添加发光效果
        particle.style.boxShadow = `0 0 10px ${color}`;
        
        // 随机速度和角度
        const angle = (i / particleCount) * Math.PI * 2;
        const speed = Math.random() * 6 + 3; // 增加速度范围
        const vx = Math.cos(angle) * speed;
        const vy = Math.sin(angle) * speed;
        
        fireworksContainer.appendChild(particle);
        
        // 粒子动画
        let startTime = null;
        const duration = Math.random() * 1500 + 1500; // 延长持续时间
        const gravity = 0.015;
        
        function animateParticle(timestamp) {
            if (!startTime) startTime = timestamp;
            const progress = (timestamp - startTime) / duration;
            
            if (progress < 1) {
                const currentX = x + vx * progress * 100;
                const currentY = y + vy * progress * 100 + 0.5 * gravity * (progress * 100) * (progress * 100);
                particle.style.left = `${currentX}px`;
                particle.style.top = `${currentY}px`;
                
                // 粒子逐渐变小并消失
                const size = (1 - progress) * (Math.random() * 4 + 1);
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.opacity = 1 - progress;
                
                requestAnimationFrame(animateParticle);
            } else {
                if (fireworksContainer.contains(particle)) {
                    fireworksContainer.removeChild(particle);
                }
            }
        }
        
        requestAnimationFrame(animateParticle);
    }
    
    // 添加额外的中心爆炸效果
    setTimeout(() => {
        const centerParticleCount = 20;
        for (let i = 0; i < centerParticleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'firework';
            particle.style.left = `${x}px`;
            particle.style.top = `${y}px`;
            particle.style.backgroundColor = selectedColors[0];
            particle.style.width = '2px';
            particle.style.height = '2px';
            particle.style.boxShadow = `0 0 8px ${selectedColors[0]}`;
            
            const angle = (i / centerParticleCount) * Math.PI * 2;
            const speed = Math.random() * 3 + 1;
            const vx = Math.cos(angle) * speed;
            const vy = Math.sin(angle) * speed;
            
            fireworksContainer.appendChild(particle);
            
            let startTime = null;
            const duration = 500;
            
            function animateCenterParticle(timestamp) {
                if (!startTime) startTime = timestamp;
                const progress = (timestamp - startTime) / duration;
                
                if (progress < 1) {
                    const currentX = x + vx * progress * 50;
                    const currentY = y + vy * progress * 50;
                    particle.style.left = `${currentX}px`;
                    particle.style.top = `${currentY}px`;
                    particle.style.opacity = 1 - progress;
                    requestAnimationFrame(animateCenterParticle);
                } else {
                    if (fireworksContainer.contains(particle)) {
                        fireworksContainer.removeChild(particle);
                    }
                }
            }
            
            requestAnimationFrame(animateCenterParticle);
        }
    }, 300);
}

// 修复满员小组开门功能
function enhanceRenderUI() {
    console.log('enhanceRenderUI called, openGroups:', Array.from(openGroups));
    // 在渲染UI后添加开门事件监听
    const groups = document.querySelectorAll('.group');
    
    groups.forEach(group => {
        const groupIndex = parseInt(group.getAttribute('data-group-index'));
        console.log(`Processing group ${groupIndex}, length: ${appState.groups[groupIndex].length}, classes:`, group.className);
        
        // 清除之前的事件监听器（通过移除并重新添加类来重置）
        group.classList.remove('group-door-open');
        
        // 确保开门状态在UI上正确显示
        if (openGroups.has(groupIndex)) {
            console.log(`Group ${groupIndex} is in openGroups`);
            group.classList.remove('group-full');
            group.classList.remove('group-full-overlay');
            group.classList.add('group-open-full');
            // 更新小组标题
            const title = group.querySelector('h3');
            const groupData = appState.groups[groupIndex];
            title.textContent = `小组 ${groupIndex + 1} (${groupData.length}/${groupData.length >= 8 ? groupData.length : 8}) [已开门]`;
        } else if (appState.groups[groupIndex].length >= 8) {
            console.log(`Group ${groupIndex} is full but not open`);
            // 如果小组已满但未开门，添加满员覆盖层
            group.classList.add('group-full-overlay');
            group.classList.remove('group-open-full');
        }
        
        // 检查小组是否已满（使用新的类）
        if (group.classList.contains('group-full') || group.classList.contains('group-full-overlay') || group.classList.contains('group-open-full') || appState.groups[groupIndex].length >= 8) {
            console.log(`Group ${groupIndex} is full, adding event listeners`);
            // 确保小组可以接收事件（移除pointer-events: none）
            group.style.pointerEvents = 'all';
            
            // 添加鼠标悬停效果
            group.addEventListener('mouseenter', () => {
                console.log(`Group ${groupIndex} mouseenter, openGroups.has: ${openGroups.has(groupIndex)}`);
                if (!openGroups.has(groupIndex)) {
                    group.classList.add('group-door-open');
                }
            });
            
            group.addEventListener('mouseleave', () => {
                console.log(`Group ${groupIndex} mouseleave`);
                if (!openGroups.has(groupIndex)) {
                    group.classList.remove('group-door-open');
                }
            });
            
            // 添加点击开门事件
            group.addEventListener('click', () => {
                console.log(`Group ${groupIndex} clicked, has group-door-open: ${group.classList.contains('group-door-open')}`);
                if (group.classList.contains('group-door-open')) {
                    // 切换开门状态
                    if (openGroups.has(groupIndex)) {
                        openGroups.delete(groupIndex);
                        group.classList.remove('group-door-open');
                        group.classList.add('group-full-overlay');
                        group.classList.remove('group-open-full');
                        // 更新小组标题
                        const title = group.querySelector('h3');
                        const groupData = appState.groups[groupIndex];
                        title.textContent = `小组 ${groupIndex + 1} (${groupData.length}/8)`;
                    } else {
                        openGroups.add(groupIndex);
                        group.classList.remove('group-door-open');
                        group.classList.add('group-open-full');
                        group.classList.remove('group-full-overlay');
                        group.classList.remove('group-full');
                        // 播放开门烟花效果
                        createFirework(group.getBoundingClientRect().left + group.offsetWidth / 2, group.getBoundingClientRect().top + group.offsetHeight / 2);
                        // 更新小组标题
                        const title = group.querySelector('h3');
                        const groupData = appState.groups[groupIndex];
                        title.textContent = `小组 ${groupIndex + 1} (${groupData.length}/${groupData.length >= 8 ? groupData.length : 8}) [已开门]`;
                    }
                    console.log(`Group ${groupIndex} door state changed, openGroups now:`, Array.from(openGroups));
                }
            });
        }
    });
}

// 当页面加载完成后初始化应用
document.addEventListener('DOMContentLoaded', async () => {
    await initApp();
    initPhysics();
    
    // 添加测试按钮来验证开门功能
    setTimeout(() => {
        console.log('=== 开门功能测试 ===');
        console.log('当前openGroups状态:', Array.from(openGroups));
        console.log('各小组状态:');
        appState.groups.forEach((group, index) => {
            console.log(`小组 ${index}: 成员数=${group.length}, 开门状态=${openGroups.has(index)}`);
        });
        
        // 如果没有任何满员小组，创建一个用于测试
        const fullGroups = appState.groups.filter(group => group.length >= 8);
        console.log(`找到 ${fullGroups.length} 个满员小组`);
        
        if (fullGroups.length === 0) {
            console.log('没有满员小组，开门功能需要至少一个满员小组才能测试');
            console.log('请手动将8个学生拖到一个小组中来测试开门功能');
        }
        
        // 添加一个测试按钮到页面
        const testButton = document.createElement('button');
        testButton.textContent = '测试开门功能';
        testButton.style.position = 'fixed';
        testButton.style.top = '20px';
        testButton.style.left = '20px';
        testButton.style.zIndex = '1000';
        testButton.style.padding = '10px 15px';
        testButton.style.background = 'linear-gradient(135deg, #4CAF50, #45a049)';
        testButton.style.color = 'white';
        testButton.style.border = 'none';
        testButton.style.borderRadius = '5px';
        testButton.style.cursor = 'pointer';
        testButton.style.fontWeight = 'bold';
        
        testButton.addEventListener('click', () => {
            console.log('=== 手动测试开门功能 ===');
            console.log('当前openGroups状态:', Array.from(openGroups));
            console.log('各小组状态:');
            appState.groups.forEach((group, index) => {
                console.log(`小组 ${index}: 成员数=${group.length}, 开门状态=${openGroups.has(index)}`);
            });
            
            // 检查是否有满员小组
            const fullGroupIndices = [];
            appState.groups.forEach((group, index) => {
                if (group.length >= 8) {
                    fullGroupIndices.push(index);
                }
            });
            
            if (fullGroupIndices.length > 0) {
                console.log(`找到满员小组: ${fullGroupIndices.join(', ')}`);
                console.log('请将鼠标悬停在满员小组上查看开门按钮，然后点击测试开门功能');
            } else {
                console.log('没有满员小组，无法测试开门功能');
                console.log('请手动将8个学生拖到一个小组中');
            }
        });
        
        document.body.appendChild(testButton);
        console.log('测试按钮已添加到页面左上角');
    }, 2000);
});