const path = require('path');
const fs = require('fs');

// 测试路径解析
const testUrl = '/';
const filePath = path.join(__dirname, 'wwwroot', testUrl === '/' ? 'index.html' : testUrl);

console.log('当前工作目录:', __dirname);
console.log('解析后的文件路径:', filePath);
console.log('文件是否存在:', fs.existsSync(filePath));

// 列出wwwroot目录内容
const wwwrootPath = path.join(__dirname, 'wwwroot');
console.log('\nwwwroot目录内容:');
if (fs.existsSync(wwwrootPath)) {
    const files = fs.readdirSync(wwwrootPath);
    files.forEach(file => {
        const stats = fs.statSync(path.join(wwwrootPath, file));
        console.log(`${file} (${stats.isDirectory() ? '目录' : '文件'})`);
    });
} else {
    console.log('wwwroot目录不存在');
}