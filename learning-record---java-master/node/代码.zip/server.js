// 简单的Node.js服务器，用于处理分组数据的存储
const http = require('http');
const fs = require('fs');
const path = require('path');

// 端口设置
// 使用环境变量指定端口，如果没有则使用3000，若3000被占用则自动选择可用端口
const PORT = process.env.PORT || 3000;

// 数据文件路径
const DATA_FILE = path.join(__dirname, 'group_data.json');

// 初始化数据文件
function initDataFile() {
    if (!fs.existsSync(DATA_FILE)) {
        const initialData = {
            ungrouped: [
                
            ],
            groups: Array(20).fill().map(() => [])
        };
        fs.writeFileSync(DATA_FILE, JSON.stringify(initialData, null, 2));
    }
}

// 读取数据
function readData() {
    try {
        const data = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('读取数据失败:', error);
        return null;
    }
}

// 写入数据
function writeData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('写入数据失败:', error);
        return false;
    }
}

// 创建HTTP服务器
const server = http.createServer((req, res) => {
    // 设置CORS头部
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    // 处理OPTIONS请求
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }
    
    // 处理API请求
    if (req.url === '/api/group-data' && req.method === 'GET') {
        // 读取数据
        const data = readData();
        if (data) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(data));
        } else {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: '读取数据失败' }));
        }
    } else if (req.url === '/api/group-data' && req.method === 'POST') {
        // 写入数据
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            try {
                const data = JSON.parse(body);
                const success = writeData(data);
                if (success) {
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true }));
                } else {
                    res.writeHead(500, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: '写入数据失败' }));
                }
            } catch (error) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: '无效的JSON数据' }));
            }
        });
    } else {
        // 静态文件服务 - 从wwwroot目录提供
        console.log('接收到请求:', req.url);
        
        // 解析URL，提取路径部分（忽略查询参数）
        const parsedUrl = new URL(req.url, `http://localhost:${PORT}`);
        const pathname = parsedUrl.pathname;
        
        // 构建文件路径
        let filePath;
        if (pathname === '/') {
            filePath = path.join(__dirname, 'wwwroot', 'index.html');
        } else {
            filePath = path.join(__dirname, 'wwwroot', pathname);
        }
        
        console.log('解析后的文件路径:', filePath);
        
        const extname = String(path.extname(filePath)).toLowerCase();
        const mimeTypes = {
            '.html': 'text/html',
            '.js': 'text/javascript',
            '.css': 'text/css',
            '.json': 'application/json'
        };
        
        const contentType = mimeTypes[extname] || 'application/octet-stream';
        
        fs.readFile(filePath, (error, content) => {
            if (error) {
                if (error.code === 'ENOENT') {
                    res.writeHead(404);
                    res.end('404 Not Found');
                } else {
                    res.writeHead(500);
                    res.end('500 Internal Server Error');
                }
            } else {
                res.writeHead(200, { 'Content-Type': contentType });
                res.end(content, 'utf-8');
            }
        });
    }
});

// 初始化数据文件并启动服务器
initDataFile();

// 使用递增方式查找可用端口
function startServer(startPort) {
    server.listen(startPort, '0.0.0.0', () => {
        console.log(`服务器运行在 http://0.0.0.0:${startPort}/`);
        console.log(`数据文件存储在: ${DATA_FILE}`);
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.log(`端口 ${startPort} 已被占用，尝试使用端口 ${startPort + 1}`);
            startServer(startPort + 1);
        } else {
            console.error('服务器启动错误:', err);
        }
    });
}

// 启动服务器
startServer(PORT);